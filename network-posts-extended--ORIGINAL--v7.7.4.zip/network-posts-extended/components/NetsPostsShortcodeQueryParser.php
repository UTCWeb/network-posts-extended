<?php


namespace NetworkPosts\Components;


class NetsPostsShortcodeQueryParser {
	protected $attributes;


}