<?php


namespace NetworkPosts\DB\Category;


final class CategoryInclusionMode {
	const INCLUDE_ANY  = 1;
	const INCLUDE_ALL  = 2;
	const INCLUDE_ONLY = 3;
}